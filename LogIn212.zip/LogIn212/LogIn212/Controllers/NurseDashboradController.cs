﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LogIn212.Controllers
{
    [Authorize(Roles ="Nurse")]
    public class NurseDashboradController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
